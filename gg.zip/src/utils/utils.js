const path = require("path");

exports.from_public = (file) => path.join(__dirname, +file);
